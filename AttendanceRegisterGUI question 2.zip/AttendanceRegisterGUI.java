import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class AttendanceRegisterGUI extends JFrame {
    private JLabel nameLabel, dateLabel;
    private JTextField nameField, dateField;
    private JButton submitButton, viewButton;
    private JTable table;
    private DefaultTableModel tableModel;
    private Connection connection;
    private PreparedStatement insertStatement, selectStatement;

    public AttendanceRegisterGUI() {
        initComponents();
        connectToDatabase();
    }

    private void initComponents() {
        nameLabel = new JLabel("Name:");
        nameField = new JTextField(20);
        dateLabel = new JLabel("Date:");
        dateField = new JTextField(20);
        submitButton = new JButton("Submit");
        viewButton = new JButton("View");
        tableModel = new DefaultTableModel();
        table = new JTable(tableModel);

        submitButton.addActionListener((ActionEvent e) -> {
            String name1 = nameField.getText();
            String date = dateField.getText();
            insertData(name1, date);
            nameField.setText("");
            dateField.setText("");
        });

        viewButton.addActionListener((ActionEvent e) -> {
            viewData();
        });

        JPanel panel = new JPanel();
        panel.add(nameLabel);
        panel.add(nameField);
        panel.add(dateLabel);
        panel.add(dateField);
        panel.add(submitButton);
        panel.add(viewButton);
        panel.add(new JScrollPane(table));

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Attendance Register");
        setSize(500, 400);
        setLocationRelativeTo(null);
        add(panel);
    }

    private void connectToDatabase() {
        try {
            String url = "jdbc:derby://localhost:1527/your_database_name";
            String username = "leratod.ngwasheng@gmail.com";
            String password = "Lerato@1";
            connection = DriverManager.getConnection(url, username, password);
            insertStatement = connection.prepareStatement("INSERT INTO Attendance_register (Name, Date) VALUES (?, ?)");
            selectStatement = connection.prepareStatement("SELECT * FROM Attendance_register");

        } catch (SQLException e) {
        }
    }

    private void insertData(String name, String date) {
        try {
            insertStatement.setString(1, name);
            insertStatement.setString(2, date);
            insertStatement.executeUpdate();
        } catch (SQLException e) {
        }
    }

    private void viewData() {
        try {
            ResultSet resultSet = selectStatement.executeQuery();
            tableModel.setRowCount(0);

            while (resultSet.next()) {
                String name = resultSet.getString("Name");
                String date = resultSet.getString("Date");
                tableModel.addRow(new Object[]{name, date});
            }
        } catch (SQLException e) {
        }
    }

    public static void main(String[] args) {
        AttendanceRegisterGUI gui = new AttendanceRegisterGUI();
        gui.setVisible(true);
    }
}


