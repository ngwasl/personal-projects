public abstract class BuildingMaterial {
private String productDescription;
private int QUANTITY;
double costPrice;

public String getProductDescription(){
    return productDescription;
}
  public void setProductDescription(String prodDescription) {   
      productDescription=prodDescription;
      
}
public int getQUANTITY() {
    return QUANTITY;  
}

public void setQUANTITY(int QUANTITY) {
      this.QUANTITY = QUANTITY;   
}
public double getCostPrice() {
    return costPrice;
    
}

 public void setCostPrice(double costPrice) {   
this.costPrice = costPrice;

}





    void setQuantity(int quantity) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }


    double totalCostPrice() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}