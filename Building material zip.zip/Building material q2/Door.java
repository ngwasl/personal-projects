public class Door extends BuildingMaterial {
    private double unitCost;

    public Door(String description, int quantity, double unitCost) {
        this.unitCost = unitCost;
    }

    public double getUnitCost() {
        return unitCost;
    }

    public void setUnitCost(double unitCost) {
        this.unitCost = unitCost;
    }

    public void viewDoorMenu() {
        System.out.println("Door prices:");
        System.out.println("Pine Stable Door @ R330 each");
        System.out.println("Hard Board Door @ R270 each");
    }

    @Override
    public double totalCostPrice() {
        return getQuantity() * unitCost;
    }

    private double getQuantity() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
