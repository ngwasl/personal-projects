import java.util.Scanner;

public class UseBuildingMaterial {
    public static void main(String[] args) {
        try (Scanner input = new Scanner(System.in)) {
            BuildingMaterial material = null;
            int option, quantity;
            double totalCost;
            boolean validOption = true;
            do {
                // Display menu options
                System.out.println("Please choose an option: ");
                System.out.println("1. Zinc");
                System.out.println("2. Window Frames");
                System.out.println("3. Doors");
                System.out.println("4. Exit");
                option = input.nextInt();
                
                switch (option) {
                    case 1 -> {
                        // Display zinc options
                        System.out.println("Please choose a zinc option: ");
                        System.out.println("1. Corrugated Zinc");
                        System.out.println("2. IBR Zinc");
                        int zincOption = input.nextInt();
                        
                        switch (zincOption) {
                            case 1 -> {
                                material = new Zinc("Corrugated Zinc", 0, 0.0);
                                ((Zinc) material).viewCorruZinc();
                            }
                            case 2 -> {
                                material = new Zinc("IBR Zinc", 0, 0.0);
                                ((Zinc) material).viewIBRZinc();
                            }
                            default -> {
                                System.out.println("Invalid option!");
                                validOption = false;
                            }
                        }
                    }
                    
                    case 2 -> {
                        material = new WindowFrame("Window Frames", 0, 0.0);
                        ((WindowFrame) material).viewWindowMenu();
                    }
                    case 3 -> {
                        material = new Door("Doors", 0, 0.0);
                        ((Door) material).viewDoorMenu();
                    }
                    case 4 -> System.exit(0);
                    default -> {
                        System.out.println("Invalid option!");
                        validOption = false;
                    }
                }
                
                if (validOption) {
                    // Get quantity input from user
                    System.out.println("Please enter the quantity: ");
                    quantity = input.nextInt();
                    material.setQuantity(quantity);
                    
                    // Calculate total cost and display the result
                    totalCost = material.totalCostPrice();
                    System.out.println("Total cost: R" + totalCost + "\n");
                }
                
                // Reset validOption flag
                validOption = true;
                
            } while (option != 4);
        }
    }

    private static class Zinc extends BuildingMaterial {

        public Zinc(String corrugated_Zinc, int i, double d) {
        }

        private void viewCorruZinc() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private void viewIBRZinc() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }
    }

    private static class WindowFrame extends BuildingMaterial {

        public WindowFrame(String window_Frames, int i, double d) {
        }

        private void viewWindowMenu() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }
    }

    private static class Door extends BuildingMaterial {

        public Door(String doors, int i, double d) {
        }

        private void viewDoorMenu() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }
    }
}