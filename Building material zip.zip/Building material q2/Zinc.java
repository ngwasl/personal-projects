public class Zinc extends BuildingMaterial {
    private String type;
    private double quantity;

    public Zinc(String type) {
        this.type = type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }

    @Override
    public double totalCostPrice() {
        double price = 0.0;
        // Calculate price based on quantity and cost price
        price = this.quantity * this.costPrice;
        return price;
    }

    public void viewCorruZinc() {
        // Code to display corrugated zinc options
        System.out.println("Corrugated Zinc options:");
        System.out.println("- 0.3mm");
        System.out.println("- 0.4mm");
        System.out.println("- 0.5mm");
        System.out.println("- 0.6mm");
    }

    public void viewIBRZinc() {
        // Code to display IBR zinc options
        System.out.println("IBR Zinc options:");
        System.out.println("- 0.4mm");
        System.out.println("- 0.5mm");
        System.out.println("- 0.6mm");
        System.out.println("- 0.8mm");
    }
}