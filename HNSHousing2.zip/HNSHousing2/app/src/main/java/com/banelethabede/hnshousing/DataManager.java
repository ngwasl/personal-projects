package com.banelethabede.hnshousing;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DataManager extends SQLiteOpenHelper {
    private SQLiteDatabase db;
    public static final String TABLE_ROW_ID = "_id";
    public static final String TABLE_ROW_TYPE = "Type";
    public static final String TABLE_ROW_PROBLEM = "Problem";
    public static final String TABLE_ROW_ISSUE = "issue";
    public static final String TABLE_ROW_DESCRIPTION = "DESCRIPTION";
    public static final String TABLE_ROW_REFERENCE = "reference";
    public static final String TABLE_ROW_ADDRESS = "address";
    public static final String TABLE_ROW_NAME = "name";
    public static final String TABLE_ROW_CONTACTNUMBER = "contact_number";
    public static final String TABLE_ROW_EMAIL= "email";

    private static final String DB_NAME = "housing_problem_info";
    private static final int DB_VERSION = 1;
    private static final String TABLE_NAME = "housingInformation";
    private int intContactNumber;
    SharedPreferences sp;
    private String  strProblem,strType, strIssues, strDescription, strReference, strAddress, strName, strEmail;

    public DataManager(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
        this.db = db;
        sp = context.getSharedPreferences("myUserPrefs",Context.MODE_PRIVATE);
    }
    public void  getData(){

        strProblem = sp.getString("problem","DEFAULT");
        strIssues = sp.getString("issue","CHH") ;
        strDescription = sp.getString("description","DV");
        strReference =sp.getString("reference","JJ");
        strAddress = sp.getString("address","FF");
        strName = sp.getString("name","AA");
        intContactNumber = sp.getInt("contactNumber",-1);
        strEmail = sp.getString("email","DD");
        strType = sp.getString("type","BB");
    }


    public void insert(){
        getData();
        db = getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(TABLE_ROW_NAME,strName);
        values.put(TABLE_ROW_ADDRESS,strAddress);
        values.put(TABLE_ROW_PROBLEM,strProblem);
        values.put(TABLE_ROW_ISSUE,strIssues);
        values.put(TABLE_ROW_DESCRIPTION,strDescription);
        values.put(TABLE_ROW_REFERENCE,strReference);
        values.put(TABLE_ROW_CONTACTNUMBER,intContactNumber);
        values.put(TABLE_ROW_EMAIL,strEmail);
        values.put(TABLE_ROW_TYPE,strType);

        db.insert(TABLE_NAME,null,values);
        db.close();
    }

    public void updateRecords(int id){
        getData();
        db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(TABLE_ROW_NAME,strName);
        values.put(TABLE_ROW_ADDRESS,strAddress);
        values.put(TABLE_ROW_PROBLEM,strProblem);
        values.put(TABLE_ROW_ISSUE,strIssues);
        values.put(TABLE_ROW_DESCRIPTION,strDescription);
        values.put(TABLE_ROW_REFERENCE,strReference);
        values.put(TABLE_ROW_CONTACTNUMBER,intContactNumber);
        values.put(TABLE_ROW_EMAIL,strEmail);
        values.put(TABLE_ROW_TYPE,strType);
        db.update(TABLE_NAME,values,TABLE_ROW_ID+"=?",new String[]{String.valueOf(id)});
        db.close();

    }
    public void deleteRecords(int id){

        db = getWritableDatabase();
        db.delete(TABLE_NAME,TABLE_ROW_ID+ "=?",new String[]{String.valueOf(id)});
        db.close();

    }
    public ArrayList<UpdateModel> readRecords(){
        db = getReadableDatabase();
        Cursor cursor = db.rawQuery("Select * From "+ TABLE_NAME,null);
        ArrayList<UpdateModel> updateModelArrayList = new ArrayList<>();


        if(cursor.moveToFirst()){
            do {
                updateModelArrayList.add(new UpdateModel(
                        cursor.getInt(0),
                        cursor.getString(1),
                        cursor.getString(2),
                        cursor.getString(3),
                        cursor.getString(4),
                        cursor.getString(5),
                        cursor.getString(6),
                        cursor.getInt(7),
                        cursor.getString(8),
                        cursor.getString(9)));

            } while (cursor.moveToNext());

        }
        cursor.close();
        db.close();
        return updateModelArrayList;
    }
    @Override
        public void onCreate(SQLiteDatabase sqLiteDatabase) {
            String newTableQueryString = "create table "
                    + TABLE_NAME
                    + " ("
                    + TABLE_ROW_ID
                    + " integer primary key autoincrement not null, "
                    + TABLE_ROW_NAME
                    + " text not null, "
                    + TABLE_ROW_ADDRESS
                    + " text not null, "
                    + TABLE_ROW_PROBLEM
                    + " text not null, "
                    + TABLE_ROW_ISSUE
                    + " text not null, "
                    + TABLE_ROW_DESCRIPTION
                    +" text not null, "
                    + TABLE_ROW_REFERENCE
                    + " text not null, "
                    + TABLE_ROW_CONTACTNUMBER
                    + " integer not null, "
                    + TABLE_ROW_EMAIL
                    + " text not null, "
                    + TABLE_ROW_TYPE
                    + " text not Null"
                     +");";

            sqLiteDatabase.execSQL(newTableQueryString);
        }

        @Override
        public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
            db.execSQL("Drop table if exists " + TABLE_NAME);
            onCreate(db);

        }
    }



