package com.banelethabede.hnshousing;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class DescribtionPage extends AppCompatActivity implements View.OnClickListener {
    private static final String TAG = " DescribtionPage";
    EditText mProblem, mIssues, mDescription, mReference, mAddress, mName, mContact, mEmail;
    int intContactNumber;
    String  strProblem, strmIssues, strDescription, strReference, strAddress, strName, strEmail,
            strType;
    Button btnSubmit, btnViewUpdate;
    SharedPreferences preferences ;
    private DataManager dataManager;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.description_page);
        dataManager = new DataManager(DescribtionPage.this);
        initUIElements();
        mDescription.setText(getIntent().getStringExtra("description"));

    }
    @Override
    public void onClick(View view) {
        SharedPreferences.Editor editor = preferences.edit();
        switch (view.getId()){

                case R.id.btnSubmit:
                    getData();
                    //validating Data
                    if( strProblem.isEmpty()|| strmIssues.isEmpty()|| strDescription.isEmpty()||
                            strReference.isEmpty()|| strAddress.isEmpty() ||strName.isEmpty() ||
                             strEmail.isEmpty() || strType.isEmpty()){
                        Toast.makeText(DescribtionPage.this,"Please make sure all the fields are " +
                                "filled",Toast.LENGTH_LONG).show();
                        return;
                    }




                    editor.putString("problem",strProblem);
                    editor.putString("description",strDescription);
                    editor.putString("reference",strReference);
                    editor.putString("issue",strmIssues);
                    editor.putString("address",strAddress);
                    editor.putString("name",strName);
                    editor.putInt("contactNumber",intContactNumber);
                    editor.putString("email",strEmail);
                    editor.putString("type",strType);
                    editor.commit();
                    dataManager.insert();
                    Intent intent = new Intent(DescribtionPage.this,MainActivity.class);
                    Toast.makeText(DescribtionPage.this,"Data Has Been Saved",Toast.LENGTH_LONG).show();
                    startActivity(intent);
                    break;

        }

    }
    public void initUIElements(){
        mProblem = findViewById(R.id.editTextProblem);
        mDescription  = findViewById(R.id.editTextDescribtion);
        mReference  = findViewById(R.id.editTextReference);
        mIssues  = findViewById(R.id.editTextIssues);
        mAddress  = findViewById(R.id.editTextAddress);
        mName = findViewById(R.id.editTextName);
        mContact  = findViewById(R.id.editTextContactNumber);
        mEmail  = findViewById(R.id.editTextEmail);
        preferences = getSharedPreferences("myUserPrefs",MODE_PRIVATE);

        //Buttons
        btnSubmit =findViewById(R.id.btnSubmit);
        btnSubmit.setOnClickListener(this);

    }
    public void getData(){
        try {
            strProblem = mProblem.getText().toString();
            strmIssues = mIssues.getText().toString();
            strDescription = mDescription.getText().toString();
            strReference = mReference.getText().toString();
            strAddress = mAddress.getText().toString();
            strName = mName.getText().toString();
            intContactNumber = Integer.parseInt(String.valueOf(mContact.getText()));
            strEmail = mEmail.getText().toString();
            strType = preferences.getString("type"," ");
        } catch (Exception e){
            Log.i(TAG," DescribtionPage.getdata()");
        }


    }

}
