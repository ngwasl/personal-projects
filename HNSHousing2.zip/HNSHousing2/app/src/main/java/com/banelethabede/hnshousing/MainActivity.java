package com.banelethabede.hnshousing;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    RecyclerView view;
   SharedPreferences preferences;
    Button btnFurniture,btnElectrical,btnPlumbing, btnViewRecords;
    TextView textView;
    //For debug
    private static final String TAG = "MainActivity";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.landing_page);
        Log.d(TAG, "STarted");
        preferences = getSharedPreferences("myUserPrefs", Context.MODE_PRIVATE);

        textView = findViewById(R.id.textView);

        btnFurniture = findViewById(R.id.btnFurniture);
        btnFurniture.setOnClickListener(this);

        btnElectrical = findViewById(R.id.btnElectrical);
        btnElectrical.setOnClickListener(this);

        btnViewRecords = findViewById(R.id.btnViewRecords);
        btnViewRecords.setOnClickListener(this);

        btnPlumbing = findViewById(R.id.btnPlumbing);
        btnPlumbing.setOnClickListener(this);


    }




    private void initRecycleview(ArrayList<String> arrayList){
        Log.i(TAG,"init Recycleview");
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        RecyclerViewAdapter adapter = new RecyclerViewAdapter(arrayList,this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.addItemDecoration(new DividerItemDecoration(this,LinearLayoutManager.VERTICAL));
        recyclerView.setAdapter(adapter);
    }

    @Override
    public void onClick(View view) {
        SharedPreferences.Editor editor = preferences.edit();
        switch (view.getId()){

            case R.id.btnElectrical:

                setContentView(R.layout.problem_page);
                ArrayList<String> electricalProblemList = new ArrayList<>();
                electricalProblemList.add("Frequent Electrical Surges");
                electricalProblemList.add("Sags And Dips In Power");
                electricalProblemList.add("Light Switches Not Working Properly");
                electricalProblemList.add("Circuit Breaker Tripping Frequently");
                electricalProblemList.add("Circuit Overload");
                electricalProblemList.add("Lights Too Bright Or Dim");
                electricalProblemList.add("Electrical Shocks");
                electricalProblemList.add("High Electrical Bill");
                initRecycleview(electricalProblemList);
                editor.putString("type","Electrical");
                editor.commit();
                break;

            case R.id.btnFurniture:
                setContentView(R.layout.problem_page);
                ArrayList<String> furnitureProblemList = new ArrayList<>();
                furnitureProblemList.add("Loose Rungs on Your Chairs");
                furnitureProblemList.add("Wobbly Chairs");
                furnitureProblemList.add("Pieces Coming Apart at the Seams");
                furnitureProblemList.add("Loose Legs");
                furnitureProblemList.add("Broken Drawer Corners");
                furnitureProblemList.add("Uneven Table");
                furnitureProblemList.add("Busted Handles");
                furnitureProblemList.add("Those Pesky Scratches");
                furnitureProblemList.add("Deep Surface Damage");
                initRecycleview(furnitureProblemList);
                editor.putString("type","Furniture");
                editor.commit();
                break;

            case R.id.btnPlumbing:
                setContentView(R.layout.problem_page);
                ArrayList<String> plumbingProblemList = new ArrayList<>();
                plumbingProblemList.add("Dripping Faucets");
                plumbingProblemList.add("Leaky Pipes");
                plumbingProblemList.add("Running Toilets");
                plumbingProblemList.add("Low Water Pressure");
                plumbingProblemList.add("Leaking Hose Bib");
                plumbingProblemList.add("Slow or Clogged Drains");
                plumbingProblemList.add("Water Heater Problems");
                plumbingProblemList.add("Sump Pump Failure");
                plumbingProblemList.add("Water Heater Problems");
                initRecycleview(plumbingProblemList);
                editor.putString("type","Plumbing");
                editor.commit();
                break;

            case R.id.btnViewRecords:
                Intent records = new Intent(MainActivity.this, ViewRecords.class);
                startActivity(records);
                break;

            case R.id.btnBackLandingPage:
                Intent Landing = new Intent(MainActivity.this,MainActivity.class);
                startActivity(Landing);
                break;

        }
   }
}