package com.banelethabede.hnshousing;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;


public class RecordsAdapter extends RecyclerView.Adapter<RecordsAdapter.ViewHolder> {
    private final ArrayList<UpdateModel> updateModelArrayList;
    private final Context mContext;
    SharedPreferences preferences;


    public RecordsAdapter(ArrayList<UpdateModel> updateModelArrayList, Context mContext) {
        this.updateModelArrayList = updateModelArrayList;
        this.mContext = mContext;
        preferences = mContext.getSharedPreferences("dataRequest",Context.MODE_PRIVATE);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.records_adapter,parent
                ,false);
        ViewHolder holder = new  ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        UpdateModel updateModel = updateModelArrayList.get(position);
        holder.txtViewName.setText(updateModel.getmName());
        holder.txtViewEmail.setText(updateModel.getmEmail());
        holder.txtViewType.setText(updateModel.getmType());
        holder.txtViewContactNumber.setText(String.valueOf(updateModel.getmContactNUmber()));
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(mContext,UpdateRecords.class);
                intent.putExtra("address", updateModel.getmAddress());
                intent.putExtra("issues", updateModel.getmIssues());
                intent.putExtra("descriptions", updateModel.getmDescription());
                intent.putExtra("problem", updateModel.getmProblem());
                intent.putExtra("reference", updateModel.getmReference());
                intent.putExtra("name", updateModel.getmName());
                intent.putExtra("contactnumber", updateModel.getmContactNUmber());
                intent.putExtra("email", updateModel.getmEmail());
                intent.putExtra("type", updateModel.getmType());
                intent.putExtra("id",updateModel.getmId());
                mContext.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return updateModelArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView txtViewName, txtViewContactNumber , txtViewType , txtViewEmail;
        CardView RecordsCV;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            txtViewName = itemView.findViewById(R.id.textviewName);
            txtViewContactNumber = itemView.findViewById(R.id.textViewContactNumber);
            txtViewType = itemView.findViewById(R.id.textViewType);
            txtViewEmail = itemView.findViewById(R.id.textViewEmail);
            RecordsCV = itemView.findViewById(R.id.RecordsCV);
        }
    }
}
