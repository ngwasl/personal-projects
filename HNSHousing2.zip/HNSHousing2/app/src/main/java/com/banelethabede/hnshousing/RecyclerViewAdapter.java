package com.banelethabede.hnshousing;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class RecyclerViewAdapter extends  RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {
    private static final String TAG = "RecyclerViewAdapter";


    LinearLayout linearLayout;
    private final List<String> problemLIst;
    private final Context mContext;
    public RecyclerViewAdapter(List<String> problemLIst, Context mContext) {
        this.problemLIst = problemLIst;
        this.mContext = mContext;

    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_listitem,parent,false);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Log.d(TAG, "binderclalled");
        String nameHolder = problemLIst.get(position);
        holder.textView.setText(nameHolder);
        holder.textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(mContext,DescribtionPage.class);
                intent.putExtra("description",nameHolder);
                mContext.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return problemLIst.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView textView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            textView = itemView.findViewById(R.id.textView);
            linearLayout = itemView.findViewById(R.id.Parent_layout);

        }


    }
}


