package com.banelethabede.hnshousing;

public class UpdateModel {
    private int mId;
    private String mName,mAddress, mProblem, mIssues, mDescription, mReference;
    private int mContactNUmber;
    private String mEmail,mType;

    public UpdateModel(int mId, String mName, String mAddress, String mProblem, String mIssues,
                       String mDescription, String mReference, int mContactNUmber, String mEmail,
                       String mType)
    {
        this.mId = mId;
        this.mName = mName;
        this.mAddress = mAddress;
        this.mProblem = mProblem;
        this.mIssues = mIssues;
        this.mDescription = mDescription;
        this.mReference = mReference;
        this.mContactNUmber = mContactNUmber;
        this.mEmail = mEmail;
        this.mType = mType;
    }

    public int getmId() {
        return mId;
    }

    public void setmId(int mId) {
        this.mId = mId;
    }

    public String getmName() {
        return mName;
    }

    public void setmName(String mName) {
        this.mName = mName;
    }

    public String getmAddress() {
        return mAddress;
    }

    public void setmAddress(String mAddress) {
        this.mAddress = mAddress;
    }

    public String getmProblem() {
        return mProblem;
    }

    public void setmProblem(String mProblem) {
        this.mProblem = mProblem;
    }

    public String getmIssues() {
        return mIssues;
    }

    public void setmIssues(String mIssues) {
        this.mIssues = mIssues;
    }

    public String getmDescription() {
        return mDescription;
    }

    public void setmDescription(String mDescription) {
        this.mDescription = mDescription;
    }

    public String getmReference() {
        return mReference;
    }

    public void setmReference(String mReference) {
        this.mReference = mReference;
    }

    public int getmContactNUmber() {
        return mContactNUmber;
    }

    public void setmContactNUmber(int mContactNUmber) {
        this.mContactNUmber = mContactNUmber;
    }

    public String getmEmail() {
        return mEmail;
    }

    public void setmEmail(String mEmail) {
        this.mEmail = mEmail;
    }

    public String getmType() {
        return mType;
    }

    public void setmType(String mType) {
        this.mType = mType;
    }
}

