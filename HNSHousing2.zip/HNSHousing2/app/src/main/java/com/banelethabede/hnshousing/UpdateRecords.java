package com.banelethabede.hnshousing;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class UpdateRecords extends AppCompatActivity {

    private static final String TAG = "UpdateRecords";
    EditText mProblem, mIssues, mDescription, mReference, mAddress, mName, mContact, mEmail;
    int ContactNumber,id;
     String  strProblem,strType, strmIssues, strDescription, strReference, strAddress, strName, strEmail;
     Button btnSave,btnDelete;
    SharedPreferences preferences ;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.update_page);
        initUIElements();
        preferences= getSharedPreferences("myUserPrefs", Context.MODE_PRIVATE);

        DataManager dataManager=  new DataManager(UpdateRecords.this);

        strAddress = getIntent().getStringExtra("address");
        strDescription = getIntent().getStringExtra("descriptions");
        strType = getIntent().getStringExtra("type");
        strmIssues = getIntent().getStringExtra("issues");
        strProblem = getIntent().getStringExtra("problem");
        strReference = getIntent().getStringExtra("reference");
        strName = getIntent().getStringExtra("reference");
        strEmail = getIntent().getStringExtra("email");
        ContactNumber = getIntent().getIntExtra("contactnumber",-1);
        id = getIntent().getIntExtra("id",-1);

        mProblem.setText(strProblem);
        mIssues.setText(strmIssues);
        mDescription.setText(strDescription);
        mReference.setText(strReference);
        mAddress.setText(strAddress);
        mName.setText(strName);
        mContact.setText(String.valueOf(ContactNumber));
        mEmail.setText(strEmail);

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences.Editor editor = preferences.edit();
                if( strProblem.isEmpty()|| strmIssues.isEmpty()|| strDescription.isEmpty()||
                        strReference.isEmpty()|| strAddress.isEmpty() ||strName.isEmpty() ||
                        strEmail.isEmpty() || strType.isEmpty()){
                    Toast.makeText(UpdateRecords.this,"Please make sure all the fields are " +
                            "filled",Toast.LENGTH_LONG).show();
                    return;
                }
                getData();
                editor.putString("problem",strProblem);
                editor.putString("description",strDescription);
                editor.putString("reference",strReference);
                editor.putString("issue",strmIssues);
                editor.putString("address",strAddress);
                editor.putString("name",strName);
                editor.putInt("contactNumber",ContactNumber);
                editor.putString("email",strEmail);
                editor.putString("type",strType);
                editor.commit();
                dataManager.updateRecords(id);
                Toast.makeText(UpdateRecords.this, "Record Updated..", Toast.LENGTH_SHORT).show();
                // launching main activity.
                Intent i = new Intent(UpdateRecords.this, MainActivity.class);
                startActivity(i);
            }
        });

        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            getData();
            dataManager.deleteRecords(id);
                Intent i = new Intent(UpdateRecords.this, MainActivity.class);
                startActivity(i);
            }
        });
    }
    public void getData(){
        try {
            strProblem = mProblem.getText().toString();
            strmIssues = mIssues.getText().toString();
            strDescription = mDescription.getText().toString();
            strReference = mReference.getText().toString();
            strAddress = mAddress.getText().toString();
            strName = mName.getText().toString();
            ContactNumber = Integer.parseInt(String.valueOf(mContact.getText()));
            strEmail = mEmail.getText().toString();
            strType =preferences.getString("type"," ");
        } catch (Exception e){
            Log.i(TAG," UpdateRecords.getdata()");
        }

    }

    public void initUIElements() {
        mProblem = findViewById(R.id.editTextProblemUP);
        mDescription = findViewById(R.id.editTextDescribtionUP);
        mReference = findViewById(R.id.editTextReferenceUP);
        mIssues = findViewById(R.id.editTextIssuesUP);
        mAddress = findViewById(R.id.editTextAddressUP);
        mName = findViewById(R.id.editTextNameUP);
        mContact = findViewById(R.id.editTextContactNumberUP);
        mEmail = findViewById(R.id.editTextEmailUP);
        btnSave = findViewById(R.id.btnSave);
        btnDelete = findViewById(R.id.btnDelete);
    }

}
