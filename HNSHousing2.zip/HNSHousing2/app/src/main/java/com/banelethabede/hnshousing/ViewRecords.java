package com.banelethabede.hnshousing;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ViewRecords extends AppCompatActivity {
    ArrayList<UpdateModel> updateModelArrayList;
    DataManager dataManager;
    RecordsAdapter recordsAdapter;
    RecyclerView recordsRV;
    Button btnSave;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.records_layout);

        btnSave = findViewById(R.id.btnBackRecordsPage);

        updateModelArrayList = new ArrayList<>();
        dataManager = new DataManager(ViewRecords.this);

        updateModelArrayList = dataManager.readRecords();

        recordsAdapter = new RecordsAdapter(updateModelArrayList,ViewRecords.this);
        recordsRV = findViewById(R.id.RecordsRV);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager
                (ViewRecords.this, RecyclerView.VERTICAL,false);
        recordsRV.setLayoutManager(linearLayoutManager);
        recordsRV.setAdapter(recordsAdapter);

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent Landing = new Intent(ViewRecords.this,MainActivity.class);
                startActivity(Landing);

            }
        });




    }
}
