package madconalds;

import java.io.*;
import java.util.logging.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Madconalds {

    public static void main(String[] args) {
       new MeunFood().setVisible(true);
       
    }

}
