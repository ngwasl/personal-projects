package com.example.multilingualprototype;

import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private SharedPreferenceManager preferenceManager;
    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize SharedPreferenceManager instance
        preferenceManager = new SharedPreferenceManager(getApplicationContext());

        // Get reference to the TextView
        textView = findViewById(R.id.textView);

        // Set the toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Load the saved locale
        loadLocale();

        // Set the text in the TextView
        textView.setText(R.string.interface1_textview);
        textView.setText(R.string.interface2_textview);

    }

    private void loadLocale() {
        // Retrieve the saved language preference
        String savedLanguage = preferenceManager.getSelectedLanguage();

        // Set the app's locale based on the saved language
        Locale locale;
        if (savedLanguage.equals("English")) {
            locale = new Locale("en");
        } else if (savedLanguage.equals("Zulu")) {
            locale = new Locale("zu");
        } else if (savedLanguage.equals("Afrikaans")) {
            locale = new Locale("af");
        } else {
            // Default to the device's locale if no language is saved
            locale = Locale.getDefault();
        }

        Resources resources = getResources();
        Configuration configuration = resources.getConfiguration();
        configuration.setLocale(locale);
        resources.updateConfiguration(configuration, resources.getDisplayMetrics());
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemId = item.getItemId();

        if (itemId == R.id.action_language_english) {
            preferenceManager.setSelectedLanguage("English");
            recreateActivity();
            return true;
        } else if (itemId == R.id.action_language_zulu) {
            preferenceManager.setSelectedLanguage("Zulu");
            recreateActivity();
            return true;
        } else if (itemId == R.id.action_language_afrikaans) {
            preferenceManager.setSelectedLanguage("Afrikaans");
            recreateActivity();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void recreateActivity() {
        finish();
        startActivity(getIntent());
    }
}
