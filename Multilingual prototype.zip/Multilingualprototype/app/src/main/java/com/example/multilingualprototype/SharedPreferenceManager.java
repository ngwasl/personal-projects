package com.example.multilingualprototype;

import android.content.Context;
import android.content.SharedPreferences;

public class SharedPreferenceManager {
    private static final String PREF_NAME = "LanguagePreference";
    private static final String KEY_SELECTED_LANGUAGE = "SelectedLanguage";

    private SharedPreferences sharedPreferences;

    public SharedPreferenceManager(Context context) {
        sharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public void setSelectedLanguage(String language) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(KEY_SELECTED_LANGUAGE, language);
        editor.apply();
    }

    public String getSelectedLanguage() {
        return sharedPreferences.getString(KEY_SELECTED_LANGUAGE, "");
    }
}


