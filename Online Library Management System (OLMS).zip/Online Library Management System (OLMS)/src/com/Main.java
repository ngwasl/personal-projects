package com;

import com.library.dao.BookDAO;
import com.library.model.Book;

public class Main {

    public static void main(String[] args) {
        BookDAO bookDAO = new BookDAO();

        // Adding a book
        Book bookToAdd = new Book("Sample Title", "Sample Author", "1234567890", true);
        bookDAO.addBook(bookToAdd);

        // Getting a book by ISBN
        String isbnToSearch = "1234567890";
        Book foundBook = bookDAO.getBookByIsbn(isbnToSearch);
        if (foundBook != null) {
            System.out.println("Found Book: " + foundBook.getTitle());
        } else {
            System.out.println("Book not found for ISBN: " + isbnToSearch);
        }

        // Updating a book
        if (foundBook != null) {
            foundBook.setTitle("Updated Title");
            foundBook.setAuthor("Updated Author");
            bookDAO.updateBook(foundBook);
            System.out.println("Book updated successfully.");
        }

        // Deleting a book
        String isbnToDelete = "1234567890";
        bookDAO.deleteBook(isbnToDelete);
        System.out.println("Book deleted successfully.");

        // Retrieving all books
        System.out.println("All Books:");
        bookDAO.getAllBooks().forEach(b -> System.out.println(b.getTitle()));
    }
}


