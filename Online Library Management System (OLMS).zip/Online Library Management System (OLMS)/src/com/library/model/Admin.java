package com.library.model;

public class Admin extends User {
    public Admin(int userId, String username, String password) {
        super(userId, username, password);
    }

    public void addUser(User user) {
        // Add user logic
    }

    public void updateUser(User user) {
        // Update user logic
    }

    public void deleteUser(int userId) {
        // Delete user logic
    }

    public void processLoanRequest(int bookId, boolean accept) {
        // Process loan request logic
    }
}

