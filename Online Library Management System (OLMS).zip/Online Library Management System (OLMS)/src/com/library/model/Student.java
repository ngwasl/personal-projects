package com.library.model;

public class Student extends User {
    public Student(int userId, String username, String password) {
        super(userId, username, password);
    }

    public void borrowBook(int bookId) {
        // Borrow book logic
    }
}

