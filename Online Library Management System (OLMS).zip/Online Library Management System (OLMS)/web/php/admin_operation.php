<?php
include 'database.php';

$action = $_GET['action'];

if ($action == 'view_users') {
    $sql = "SELECT * FROM users";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "ID: " . $row["id"]. " - Username: " . $row["username"]. " - Role: " . $row["role"]. "<br>";
        }
    } else {
        echo "0 results";
    }
}
?>
