<?php
include 'database.php';

$action = $_GET['action'];

if ($action == 'add') {
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $title = $_POST['title'];
        $author = $_POST['author'];
        $isbn = $_POST['isbn'];
        $available = $_POST['available'];

        $sql = "INSERT INTO books (title, author, isbn, available) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssi", $title, $author, $isbn, $available);
        
        if ($stmt->execute()) {
            echo "Book added successfully.";
        } else {
            echo "Error adding book: " . $stmt->error;
        }

        $stmt->close();
    }
} elseif ($action == 'update') {
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $id = $_POST['id'];
        $title = $_POST['title'];
        $author = $_POST['author'];
        $isbn = $_POST['isbn'];
        $available = $_POST['available'];

        $sql = "UPDATE books SET title=?, author=?, isbn=?, available=? WHERE id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssii", $title, $author, $isbn, $available, $id);
        
        if ($stmt->execute()) {
            echo "Book updated successfully.";
        } else {
            echo "Error updating book: " . $stmt->error;
        }

        $stmt->close();
    }
} elseif ($action == 'delete') {
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $id = $_POST['id'];

        $sql = "DELETE FROM books WHERE id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id);
        
        if ($stmt->execute()) {
            echo "Book deleted successfully.";
        } else {
            echo "Error deleting book: " . $stmt->error;
        }

        $stmt->close();
    }
}

$conn->close();
?>

