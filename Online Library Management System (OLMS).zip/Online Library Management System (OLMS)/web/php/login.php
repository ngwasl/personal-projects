<?php
session_start();
include 'database.php';

$username = $_POST['username'];
$password = $_POST['password'];
$role = $_POST['role'];

if ($role == 'student') {
    $sql = "SELECT * FROM users WHERE username=? AND password=? AND role='student'";
} else {
    $sql = "SELECT * FROM users WHERE username=? AND password=? AND role='admin'";
}

$stmt = $conn->prepare($sql);
$stmt->bind_param('ss', $username, $password);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
    $_SESSION['username'] = $user['username'];
    $_SESSION['role'] = $user['role'];
    if ($role == 'student') {
        header('Location: student_dashboard.php');
    } else {
        header('Location: admin_dashboard.php');
    }
} else {
    echo "Invalid username or password.";
}

$stmt->close();
$conn->close();
?>
