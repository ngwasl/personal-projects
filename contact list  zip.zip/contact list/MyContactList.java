import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class MyContactList {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        // Prompt user for first name
        System.out.print("Enter your first name: ");
        String firstName = input.nextLine();
        
        // Prompt user for email address
        System.out.print("Enter your email address: ");
        String email = input.nextLine();
        
        // Create FileWriter object
        FileWriter writer = null;
        try {
            // Open the file for appending
            writer = new FileWriter("contact_list.txt", true);
            
            // Write the first name and email address to the file
            writer.write(firstName + "," + email + "\n");
            
            // Close the writer
            writer.close();
            
            System.out.println("Contact saved successfully!");
        } catch (IOException e) {
            // Handle the exception if the file cannot be written to
            System.out.println("An error occurred while saving the contact.");
            e.printStackTrace();
        } finally {
            // Close the writer if it was not already closed
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
