import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class PrintContactList {

    public static void main(String[] args) {
        try {
            BufferedReader reader = new BufferedReader(new FileReader("contacts.txt"));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] contact = line.split(",");
                String firstName = contact[0];
                String email = contact[1];
                System.out.println(firstName + ": " + email);
            }
            reader.close();
        } catch (FileNotFoundException e) {
            System.err.println("File not found: " + e.getMessage());
        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
        }
    }
}
