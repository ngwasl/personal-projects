-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3307
-- Generation Time: Jun 10, 2024 at 11:14 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `musicology_warehouse`
--

-- --------------------------------------------------------

--
-- Table structure for table `albums`
--

CREATE TABLE `albums` (
  `AlbumID` int(11) NOT NULL,
  `Title` varchar(255) NOT NULL,
  `Artist` varchar(255) NOT NULL,
  `ReleaseYear` year(4) DEFAULT NULL,
  `Genre` varchar(100) DEFAULT NULL,
  `Price` decimal(10,2) NOT NULL,
  `Description` text DEFAULT NULL,
  `StockQuantity` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `albums`
--

INSERT INTO `albums` (`AlbumID`, `Title`, `Artist`, `ReleaseYear`, `Genre`, `Price`, `Description`, `StockQuantity`) VALUES
(11, 'Amazing Grace', 'Aretha Franklin', '1972', 'Gospel', 15.99, 'Classic gospel album by Aretha Franklin', 50),
(12, 'The Miseducation of Lauryn Hill', 'Lauryn Hill', '1998', 'R&B', 14.99, 'Iconic R&B album by Lauryn Hill', 50),
(13, 'The Blueprint', 'Jay-Z', '2001', 'Hip Hop', 16.99, 'Legendary hip hop album by Jay-Z', 50),
(14, 'Fearless', 'Taylor Swift', '2008', 'Country', 13.99, 'Breakthrough country album by Taylor Swift', 50),
(15, 'Thriller', 'Michael Jackson', '1982', 'Pop', 17.99, 'Best-selling pop album by Michael Jackson', 50);

-- --------------------------------------------------------

--
-- Table structure for table `cds`
--

CREATE TABLE `cds` (
  `CDID` int(11) NOT NULL,
  `Title` varchar(255) NOT NULL,
  `Artist` varchar(255) NOT NULL,
  `ReleaseYear` year(4) DEFAULT NULL,
  `Genre` varchar(100) DEFAULT NULL,
  `Price` decimal(10,2) NOT NULL,
  `Description` text DEFAULT NULL,
  `StockQuantity` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cds`
--

INSERT INTO `cds` (`CDID`, `Title`, `Artist`, `ReleaseYear`, `Genre`, `Price`, `Description`, `StockQuantity`) VALUES
(6, 'Amazing Grace', 'Aretha Franklin', '1972', 'Gospel', 15.99, 'Classic gospel album by Aretha Franklin', 50),
(7, 'The Miseducation of Lauryn Hill', 'Lauryn Hill', '1998', 'R&B', 14.99, 'Iconic R&B album by Lauryn Hill', 50),
(8, 'The Blueprint', 'Jay-Z', '2001', 'Hip Hop', 16.99, 'Legendary hip hop album by Jay-Z', 50),
(9, 'Fearless', 'Taylor Swift', '2008', 'Country', 13.99, 'Breakthrough country album by Taylor Swift', 50),
(10, 'Thriller', 'Michael Jackson', '1982', 'Pop', 17.99, 'Best-selling pop album by Michael Jackson', 50);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `UserID` int(11) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `FullName` varchar(100) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `City` varchar(100) DEFAULT NULL,
  `State` varchar(100) DEFAULT NULL,
  `ZipCode` varchar(20) DEFAULT NULL,
  `Country` varchar(100) DEFAULT NULL,
  `role` varchar(50) NOT NULL DEFAULT 'customer'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`UserID`, `Username`, `Email`, `Password`, `FullName`, `Address`, `City`, `State`, `ZipCode`, `Country`, `role`) VALUES
(1, 'LeratoB', 'Lerato305@icloud.com', '$2y$10$3z0jOdUsWNKw5IhLBlYKEe0v2Vl3ahzGTWD6MMAhtLGNWq8WhENBW', NULL, NULL, NULL, NULL, NULL, NULL, 'customer'),
(2, 'LesibaB', 'Lesiba@gmail.com', '$2y$10$R6r3wCwR9urYkT1MgO1QWeK8Dk1jFmjSMX3RF5fPsy6qi4pqLmuwy', NULL, NULL, NULL, NULL, NULL, NULL, 'customer'),
(3, 'leratoBosh', 'leratod.ngwasheng@gmail.com', '$2y$10$ykGxWg/Yl.W0E9PS7RGHF.0VCreCzOvAO38Mt0P0XFFBMcWQPPPoK', NULL, NULL, NULL, NULL, NULL, NULL, 'customer');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `albums`
--
ALTER TABLE `albums`
  ADD PRIMARY KEY (`AlbumID`);

--
-- Indexes for table `cds`
--
ALTER TABLE `cds`
  ADD PRIMARY KEY (`CDID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`UserID`),
  ADD UNIQUE KEY `Username` (`Username`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `albums`
--
ALTER TABLE `albums`
  MODIFY `AlbumID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `cds`
--
ALTER TABLE `cds`
  MODIFY `CDID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
