<?php
session_start();

if ($_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit();
}

include '../includes/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $artist = $_POST['artist'];
    $album_type = $_POST['album_type'];
    $album_category = $_POST['album_category'];
    $stock = $_POST['stock'];

    $sql = "INSERT INTO albums (title, artist, album_type, album_category, stock) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssi", $title, $artist, $album_type, $album_category, $stock);

    if ($stmt->execute()) {
        echo "Album added successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Add Album</title>
    <link rel="stylesheet" type="text/css" href="../css/styles.css">
</head>
<body>
    <h1>Add Album</h1>
    <a href="admin_dashboard.php">Back to Dashboard</a>
    <form method="POST" action="">
        <input type="text" name="title" placeholder="Title" required>
        <input type="text" name="artist" placeholder="Artist" required>
        <select name="album_type" required>
            <option value="non-promo">Non-Promo</option>
            <option value="promotional">Promotional</option>
            <option value="on-discount">On-Discount</option>
        </select>
        <input type="text" name="album_category" placeholder="Category" required>
        <input type="number" name="stock" placeholder="Stock" required>
        <button type="submit">Add Album</button>
    </form>
</body>
</html>
