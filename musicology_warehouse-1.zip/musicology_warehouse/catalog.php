<?php
session_start();
include '../includes/db.php';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Album Catalog</title>
    <link rel="stylesheet" type="text/css" href="../css/styles.css">
    <script src="../js/jquery.min.js"></script>
    <script src="../js/cart.js"></script>
</head>
<body>
    <h1>Album Catalog</h1>
    <a href="../logout.php">Logout</a>
    <ul>
    <?php
    $results = $conn->query("SELECT * FROM albums");
    while ($album = $results->fetch_assoc()) {
        echo "<li>{$album['title']} - {$album['artist']} ({$album['album_type']}, {$album['album_category']}) - Stock: {$album['stock']} 
        <button class='add-to-cart' data-id='{$album['id']}'>Add to Cart</button></li>";
    }
    ?>
    </ul>
</body>
</html>
