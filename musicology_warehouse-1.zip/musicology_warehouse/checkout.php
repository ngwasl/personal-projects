<?php
session_start();
if ($_SESSION['role'] !== 'customer') {
    header('Location: ../login.php');
    exit();
}
include '../includes/db.php';

$customer_id = $_SESSION['user_id'];
$cart_query = "SELECT * FROM carts WHERE customer_id = $customer_id";
$cart_result = $conn->query($cart_query);
$cart = $cart_result->fetch_assoc();

if ($cart) {
    $cart_id = $cart['id'];
    $checkout_query = "DELETE FROM cart_items WHERE cart_id = $cart_id";
    if ($conn->query($checkout_query)) {
        echo "Checkout successful";
    } else {
        echo "Error: " . $conn->error;
    }
} else {
    echo "No items to checkout";
}
header('Location: cart.php');
?>
