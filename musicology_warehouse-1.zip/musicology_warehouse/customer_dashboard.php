<?php
session_start();

if ($_SESSION['role'] !== 'customer') {
    header('Location: ../login.php');
    exit();
}

include '../includes/db.php';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Customer Dashboard</title>
    <link rel="stylesheet" type="text/css" href="../css/styles.css">
</head>
<body>
    <h1>Customer Dashboard</h1>
    <nav>
        <ul>
            <li><a href="catalog.php">View Catalog</a></li>
            <li><a href="cart.php">View Cart</a></li>
            <li><a href="../logout.php">Logout</a></li>
        </ul>
    </nav>
</body>
</html>
