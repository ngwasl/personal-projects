<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Musicology Warehouse</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <h1>Welcome to Musicology Warehouse</h1>
    <a href="login.php">Login</a> | <a href="register.php">Register</a>
</body>
</html>
