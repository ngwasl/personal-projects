$(document).ready(function() {
    // Add to cart
    $('.add-to-cart').on('click', function() {
        var albumId = $(this).data('id');
        $.ajax({
            url: 'add_to_cart.php',
            method: 'POST',
            data: { album_id: albumId },
            success: function(response) {
                if (response.success) {
                    alert('Album added to cart!');
                    updateCartCount();
                } else {
                    alert('Error adding album to cart.');
                }
            }
        });
    });

    // Update cart item quantity
    $('.update-quantity').on('change', function() {
        var cartItemId = $(this).data('id');
        var quantity = $(this).val();
        $.ajax({
            url: 'update_cart.php',
            method: 'POST',
            data: { cart_item_id: cartItemId, quantity: quantity },
            success: function(response) {
                if (response.success) {
                    alert('Cart updated successfully!');
                    location.reload();
                } else {
                    alert('Error updating cart.');
                }
            }
        });
    });

    // Remove item from cart
    $('.remove-from-cart').on('click', function() {
        var cartItemId = $(this).data('id');
        $.ajax({
            url: 'remove_from_cart.php',
            method: 'POST',
            data: { cart_item_id: cartItemId },
            success: function(response) {
                if (response.success) {
                    alert('Item removed from cart!');
                    location.reload();
                } else {
                    alert('Error removing item from cart.');
                }
            }
        });
    });

    // Update cart item count in the UI
    function updateCartCount() {
        $.ajax({
            url: 'cart_count.php',
            method: 'GET',
            success: function(response) {
                $('#cart-count').text(response.count);
            }
        });
    }

    // Initial update of cart count
    updateCartCount();
});

