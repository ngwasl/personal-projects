<?php
session_start();
include '../includes/db.php';
include '../includes/functions.php';

if (!is_logged_in()) {
    header('Location: ../login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <link rel="stylesheet" href="../css/styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            background-image: url('https://res.cloudinary.com/simpleview/image/upload/v1503605529/clients/neworleans/NOTMC_20419_e78798a3-558c-48cb-8c2a-e0c50b8d846c.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            height: 100vh;
            margin: 0;
            padding: 0;
            color: #fff;
            text-align: center;
        }

        h1, h2 {
            color: #333;
        }

        a {
            display: inline-block;
            margin: 10px;
            padding: 10px 20px;
            background-color: rgba(0, 0, 0, 0.5);
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
        }

        a:hover {
            background-color: rgba(0, 0, 0, 0.7);
            text-decoration: underline;
        }

        ul {
            list-style-type: none;
            padding: 0;
        }

        li {
            background: #fff;
            margin: 10px 0;
            padding: 10px;
            border: 1px solid #ddd;
        }
    </style>
</head>
<body>
    <h1>Dashboard</h1>
    <a href="../logout.php">Logout</a>
    <?php if (is_admin()): ?>
        <a href="manage_inventory.php">Manage Inventory</a>
    <?php endif; ?>
    <?php if (is_customer()): ?>
        <a href="cart.php">View Cart</a>
    <?php endif; ?>
</body>
</html>
