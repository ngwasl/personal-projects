<?php
session_start();
include 'includes/db.php';

$response = ['success' => false];

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['album_id'])) {
    $customer_id = $_SESSION['user_id'];
    $album_id = $_POST['album_id'];
    
    // Check if cart exists for the user
    $cart_query = "SELECT id FROM carts WHERE customer_id = $customer_id";
    $cart_result = $conn->query($cart_query);

    if ($cart_result->num_rows > 0) {
        $cart = $cart_result->fetch_assoc();
        $cart_id = $cart['id'];
    } else {
        // Create a new cart
        $conn->query("INSERT INTO carts (customer_id) VALUES ($customer_id)");
        $cart_id = $conn->insert_id;
    }

    // Check if item already in cart
    $item_query = "SELECT * FROM cart_items WHERE cart_id = $cart_id AND album_id = $album_id";
    $item_result = $conn->query($item_query);

    if ($item_result->num_rows > 0) {
        // Update quantity if item already in cart
        $conn->query("UPDATE cart_items SET quantity = quantity + 1 WHERE cart_id = $cart_id AND album_id = $album_id");
    } else {
        // Add new item to cart
        $conn->query("INSERT INTO cart_items (cart_id, album_id, quantity) VALUES ($cart_id, $album_id, 1)");
    }

    $response['success'] = true;
}

echo json_encode($response);
?>
