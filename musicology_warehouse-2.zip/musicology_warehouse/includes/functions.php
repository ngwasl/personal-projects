<?php
// Start the session
session_start();

// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "musicology_warehouse";

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname, 3307);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

/**
 * Check if the user is logged in
 *
 * @return bool
 */
function is_logged_in() {
    return isset($_SESSION['user_id']);
}

/**
 * Check if the user is an admin
 *
 * @return bool
 */
function is_admin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

/**
 * Check if the user is a customer
 *
 * @return bool
 */
function is_customer() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'customer';
}

/**
 * Function to close the database connection
 */
function close_db_connection() {
    global $conn;
    if ($conn) {
        $conn->close();
    }
}

// Example usage of closing the connection (should be called at the end of your scripts)
register_shutdown_function('close_db_connection');
?>

