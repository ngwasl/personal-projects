<?php
session_start();
include '../includes/db.php';
include '../includes/functions.php';

if (!is_customer()) {
    header('Location: ../login.php');
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Your Cart</title>
    <link rel="stylesheet" type="text/css" href="../css/styles.css">
</head>
<body>
    <h1>Your Cart</h1>
    <a href="../logout.php">Logout</a>
    <ul>
    <?php
    $customer_id = $_SESSION['user_id'];
    $cart_query = "SELECT * FROM carts WHERE customer_id = $customer_id";
    $cart_result = $conn->query($cart_query);
    $cart = $cart_result->fetch_assoc();
    if ($cart) {
        $cart_id = $cart['id'];
        $items_query = "SELECT albums.title, albums.artist, cart_items.quantity 
                        FROM cart_items 
                        JOIN albums ON cart_items.album_id = albums.id 
                        WHERE cart_items.cart_id = $cart_id";
        $items_result = $conn->query($items_query);
        while ($item = $items_result->fetch_assoc()) {
            echo "<li>{$item['title']} - {$item['artist']} (Quantity: {$item['quantity']})</li>";
        }
    } else {
        echo "<li>Your cart is empty</li>";
    }
    ?>
    </ul>
</body>
</html>
