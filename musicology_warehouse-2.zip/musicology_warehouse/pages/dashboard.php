<?php
session_start();
include '../includes/db.php';
include '../includes/functions.php';

if (!is_logged_in()) {
    header('Location: ../login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <link rel="stylesheet" href="../css/styles.css">
    <style>
        body {
    font-family: Arial, sans-serif;
    background-color: red;
    background-image: url('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQYi9L3R3QXp7q3pE0lbEhri2S64E4AHfr7Tg&s');
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
    height: 100vh;
    margin: 0;
    padding: 0;
    color: red;
    text-align: center;
}

h1, h2 {
    color:red;
}

a {
    display: inline-block;
    margin: 10px;
    padding: 10px 20px;
    background-color: rgba(0, 0, 0, 0.5);
    color: red;
    text-decoration: none;
    border-radius: 5px;
}

a:hover {
    background-color:red;
    text-decoration: underline;
}

ul {
    list-style-type: none;
    padding: 0;
}

li {
    background: red;
    margin: 10px 0;
    padding: 10px;
    border: 1px solid red;
}
    </style>
</head>
<body>
    <h1>Dashboard</h1>
    <a href="../logout.php">Logout</a>
    <?php if (is_admin()): ?>
        <a href="manage_inventory.php">Manage Inventory</a>
    <?php endif; ?>
    <?php if (is_customer()): ?>
        <a href="cart.php">View Cart</a>
    <?php endif; ?>
</body>
</html>
