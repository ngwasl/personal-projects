<?php
session_start();
include 'includes/db.php';

$response = ['success' => false];

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['cart_item_id']) && isset($_POST['quantity'])) {
    $cart_item_id = $_POST['cart_item_id'];
    $quantity = $_POST['quantity'];

    if ($quantity > 0) {
        $conn->query("UPDATE cart_items SET quantity = $quantity WHERE id = $cart_item_id");
        $response['success'] = true;
    } else {
        $conn->query("DELETE FROM cart_items WHERE id = $cart_item_id");
        $response['success'] = true;
    }
}

echo json_encode($response);
?>
