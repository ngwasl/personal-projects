<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
include 'includes/db.php';

$error = ''; // Initialize error variable

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Prepare SQL query
    $stmt = $conn->prepare("SELECT `user_id`, `username`, `email`, `password`, `role` FROM `users` WHERE username=?");
    $stmt->bind_param('s', $username);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if the user exists
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        // Verify the password
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['role'] = $user['role'];

            // Store user's name in a session variable
            $_SESSION['username'] = $user['username'];

            // Redirect to the dashboard
            header("Location: pages/dashboard.php");
            exit(); // Stop script execution
        } else {
            $error = "Invalid credentials.";
        }
    } else {
        $error = "Invalid credentials.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/login.css">
    <style>
    </style>
    <script>
        // JavaScript functions 
        function validateForm() {
            var username = document.forms["loginForm"]["username"].value;
            var password = document.forms["loginForm"]["password"].value;
            
            if (username.trim() === "") {
                alert("Username must be filled out");
                return false;
            }
            
            if (password.trim() === "") {
                alert("Password must be filled out");
                return false;
            }
            
            return true;
        }

        function togglePassword() {
            var passwordInput = document.getElementById("password");
            var toggleIcon = document.getElementById("togglePasswordIcon");
            
            if (passwordInput.type === "password") {
                passwordInput.type = "text";
                toggleIcon.textContent = "Hide";
            } else {
                passwordInput.type = "password";
                toggleIcon.textContent = "Show";
            }
        }
    </script>
</head>
<body>
    <div class="login-container">
        <h2>Login</h2>
        <form name="loginForm" method="post" action="login.php" onsubmit="return validateForm()">
            <div>
                <label>Username:</label>
                <input type="text" name="username" required>
            </div>
            <div>
                <label>Password:</label>
                <input type="password" name="password" id="password" required>
                <span class="toggle-password" id="togglePasswordIcon" onclick="togglePassword()">Show</span>
            </div>
            <button type="submit">Login</button>
            <?php if(!empty($error)) { ?>
                <p><?php echo $error; ?></p>
            <?php } ?>
            <!-- Display greeting message if set -->
            <?php if(isset($_SESSION['username'])) { ?>
                <p>Welcome, <?php echo $_SESSION['username']; ?>!</p>
            <?php } ?>
        </form>
        <a href="reset_password.php">Forgot Password?</a>
    </div>
</body>
</html>













