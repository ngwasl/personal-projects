<?php
session_start();

// Check if the user is logged in
if (isset($_SESSION['user_id'])) {
    // Save the username before destroying the session
    $username = $_SESSION['username'];
    
    // Destroy the session
    session_unset();
    session_destroy();
    
    // Redirect to the login page with a success message "user... successfully logged out"
    header("Location: login.php?logout=1&username=" . urlencode($username));
    exit();
} else {
    // If the user is not logged in, redirect to the login page
    header("Location: login.php");
    exit();
}
?>
