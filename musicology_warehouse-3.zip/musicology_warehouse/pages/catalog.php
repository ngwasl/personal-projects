<?php
session_start();

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

// Include necessary database connection
include '../includes/db.php';

// Initialize the cart if it's not set
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Handle adding product to cart
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['product_id'])) {
    $product_id = $_POST['product_id'];
    if (isset($_SESSION['cart'][$product_id])) {
        $_SESSION['cart'][$product_id]++;
    } else {
        $_SESSION['cart'][$product_id] = 1;
    }
    header("Location: catalog.php");
    exit();
}

// Fetch albums from the database
$sql = "SELECT * FROM albums";
$result = $conn->query($sql);

// Check if there are any albums
if ($result->num_rows > 0) {
    $albums = $result->fetch_all(MYSQLI_ASSOC);
} else {
    $albums = [];
}

// Fetch CDs from the database
$sql = "SELECT * FROM cds";
$result = $conn->query($sql);

// Check if there are any CDs
if ($result->num_rows > 0) {
    $cds = $result->fetch_all(MYSQLI_ASSOC);
} else {
    $cds = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Product Catalog</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="../css/catalog.css">
   
</head>
<body>
    <!-- Cart icon -->
    <a href="cart.php" class="cart-icon"><i class="fas fa-shopping-cart"></i></a>

    <!-- Product Catalog link -->
    <a href="#" class="catalog-link" onclick="showCatalog()">Product Catalog</a>

    <!-- Albums and CDs buttons -->
    <div class="category-buttons" style="margin-top: 50px;">
        <a href="albums.php" class="category-button">Albums</a>
        <a href="cds.php" class="category-button">CDs</a>
    </div>

    <!-- Albums and CDs Product Lists -->
    <div id="albumsList" class="product-list hidden"></div>
    <div id="cdsList" class="product-list hidden"></div>

    <script>
        // Function to show/hide the product catalog
        function showCatalog() {
            var albumsList = document.getElementById('albumsList');
            var cdsList = document.getElementById('cdsList');
            
            if (albumsList.classList.contains('hidden')) {
                albumsList.classList.remove('hidden');
                cdsList.classList.remove('hidden');
            } else {
                albumsList.classList.add('hidden');
                cdsList.classList.add('hidden');
            }
        }
    </script>
</body>
</html>

