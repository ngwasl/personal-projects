<?php
session_start();
include('../includes/db_connection.php');

// Assume admin user check
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] != 'admin') {
    header('Location: ../index.php');
    exit;
}

// Fetch current stock levels from the database
$albums = mysqli_query($conn, "SELECT * FROM products WHERE category='album'");
$cds = mysqli_query($conn, "SELECT * FROM products WHERE category='cd'");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $productId = $_POST['product_id'];
    $newStock = $_POST['new_stock'];

    // Update stock level in the database
    mysqli_query($conn, "UPDATE products SET stock = $newStock WHERE id = $productId");
    
    // Refresh the page to show updated stock
    header("Location: dashboard.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Music Warehouse Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="../css/dashboard.css">
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">The Music Warehouse</div>
            <nav>
                <ul>
                    <li><a href="#">Home</a></li>
                    <li><a href="catalog.php">Catalog</a></li>
                    <li><a href="#">About</a></li>
                    <li><a href="#">Contact</a></li>
                </ul>
            </nav>
            <div class="cart-container">
                <a href="#" class="cart-icon"><i class="fas fa-shopping-cart"></i></a>
                <span class="cart-value"><?php echo $cart_total_items; ?></span>
            </div>
            <a href="../logout.php" class="logout">Logout</a>
            <div class="search-container">
                <input type="text" class="search-input" placeholder="Search...">
                <i class="fas fa-search search-icon"></i>
            </div>
            <div class="greeting-message">Welcome, <?php echo $_SESSION['username']; ?>!</div>
        </div>
    </header>
    <main class="main-content">
        <h1>Admin Dashboard</h1>
        <section>
            <h2>Manage Stock Levels</h2>
            <h3>Albums</h3>
            <ul class="catalog-list">
                <?php while ($album = mysqli_fetch_assoc($albums)): ?>
                    <li>
                        <span><?php echo $album['name']; ?> (Stock: <?php echo $album['stock']; ?>)</span>
                        <form method="POST" style="display: inline;">
                            <input type="hidden" name="product_id" value="<?php echo $album['id']; ?>">
                            <input type="number" name="new_stock" min="0" required>
                            <button type="submit">Update Stock</button>
                        </form>
                    </li>
                <?php endwhile; ?>
            </ul>
            <h3>CDs</h3>
            <ul class="catalog-list">
                <?php while ($cd = mysqli_fetch_assoc($cds)): ?>
                    <li>
                        <span><?php echo $cd['name']; ?> (Stock: <?php echo $cd['stock']; ?>)</span>
                        <form method="POST" style="display: inline;">
                            <input type="hidden" name="product_id" value="<?php echo $cd['id']; ?>">
                            <input type="number" name="new_stock" min="0" required>
                            <button type="submit">Update Stock</button>
                        </form>
                    </li>
                <?php endwhile; ?>
            </ul>
        </section>
    </main>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js"></script>
    <script>
        function searchProducts() {
            var searchTerm = document.querySelector('.search-input').value;
            console.log('Searching for:', searchTerm);
        }
    </script>
</body>
</html>


