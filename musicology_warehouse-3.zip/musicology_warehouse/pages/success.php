<?php
session_start();

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Order Confirmation</title>
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <h1>Order Confirmation</h1>
    <p>Thank you for your purchase! Your order has been placed successfully.</p>

    <a href="catalog.php">Continue Shopping</a>
</body>
</html>
