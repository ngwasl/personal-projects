<?php
session_start();

// Check if 'role' key is set in the $_SESSION array
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit();
}

include '../includes/db.php';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <link rel="stylesheet" type="text/css" href="../css/styles.css">
</head>
<body>
    <h1>Admin Dashboard</h1>
    <nav>
        <ul>
            <li><a href="add_album.php">Add Album</a></li>
            <li><a href="manage_stock.php">Manage Stock</a></li>
            <li><a href="view_orders.php">View Orders</a></li>
            <li><a href="../logout.php">Logout</a></li>
        </ul>
    </nav>
</body>
</html>

