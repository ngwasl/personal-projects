<?php
session_start();

if ($_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit();
}

include '../includes/db.php';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Manage Stock</title>
    <link rel="stylesheet" type="text/css" href="../css/styles.css">
</head>
<body>
    <h1>Manage Stock</h1>
    <a href="admin_dashboard.php">Back to Dashboard</a>
    <ul>
    <?php
    $results = $conn->query("SELECT * FROM albums");
    while ($album = $results->fetch_assoc()) {
        echo "<li>{$album['title']} - {$album['artist']} ({$album['album_type']}, {$album['album_category']}) - Stock: {$album['stock']}</li>";
    }
    ?>
    </ul>
</body>
</html>
