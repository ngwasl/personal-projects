<?php
session_start();
include 'includes/db.php';

$response = ['success' => false];

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['cart_item_id'])) {
    $cart_item_id = $_POST['cart_item_id'];

    // Use prepared statement to prevent SQL injection
    $stmt = $conn->prepare("DELETE FROM cart_items WHERE id = ?");
    $stmt->bind_param('i', $cart_item_id);
    
    if ($stmt->execute()) {
        $response['success'] = true;
    }
}

echo json_encode($response);
?>

