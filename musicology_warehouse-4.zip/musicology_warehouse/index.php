<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Musicology Warehouse</title>
    <link rel="stylesheet" href="css/styles.css">
    <style>
        body, html {
            height: 100%;
            margin: 0;
            background: url('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRXivQGpunv8TrFunjwwR0okhUUCLzsuTWZDw&s') no-repeat center center fixed;
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
        }

        .welcome-container {
            text-align: center;
            margin-bottom: 20px; 
        }

        .welcome-text {
            font-size: 80px;
            font-weight: bold; 
        }

        .login-register-buttons a {
            display: inline-block;
            margin: 10px;
            padding: 10px 20px;
            text-decoration: none;
            background-color: #007bff;
            color: #fff;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .login-register-buttons a:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="welcome-container">
        <div class="welcome-text">Welcome to Musicology Warehouse</div>
        <div class="login-register-buttons">
            <a href="login.php">Login</a> 
            <a href="register.php">Register</a>
        </div>
    </div>
</body>
</html>


