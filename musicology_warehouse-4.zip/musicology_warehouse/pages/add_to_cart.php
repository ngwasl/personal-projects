<?php
session_start();

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page if user is not logged in
    header("Location: ../login.php");
    exit();
}

// Include necessary database connection
include '../includes/db.php';

// Check if product_id is provided and is a valid integer
if (isset($_POST['product_id']) && filter_var($_POST['product_id'], FILTER_VALIDATE_INT)) {
    $product_id = $_POST['product_id'];
    
    // Fetch product details
    $sql = "SELECT * FROM products WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    
    // Check for errors
    if ($stmt->error) {
        echo "Error: " . $stmt->error;
        exit();
    }
    
    $result = $stmt->get_result();
    
    if ($result->num_rows == 1) {
        $product = $result->fetch_assoc();
        
        // Add product to cart
        $user_id = $_SESSION['user_id'];
        $cart_sql = "INSERT INTO cart (user_id, product_id) VALUES (?, ?)";
        $stmt = $conn->prepare($cart_sql);
        $stmt->bind_param("ii", $user_id, $product_id);
        $stmt->execute();
        
        // Redirect back to catalog page with success message
        header("Location: catalog.php?success=1");
        exit();
    } else {
        // Product not found, redirect back to catalog page with error message
        header("Location: catalog.php?error=product_not_found");
        exit();
    }
} else {
    // Redirect back to catalog page if product_id is not provided or is not valid
    header("Location: catalog.php?error=invalid_product_id");
    exit();
}
?>
