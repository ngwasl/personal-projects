<?php
session_start();

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page if user is not logged in
    header("Location: ../login.php");
    exit();
}

// Include necessary database connection
include '../includes/db.php';

// Fetch user's cart items
$user_id = $_SESSION['user_id'];
$sql = "SELECT products.name AS product_name, products.price AS product_price FROM cart INNER JOIN products ON cart.product_id = products.id WHERE cart.user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

// Calculate total amount
$total_amount = 0;
while ($row = $result->fetch_assoc()) {
    $total_amount += $row['product_price'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Payment Methods</title>
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <h1>Payment Methods</h1>
    <h2>Order Summary</h2>
    <ul>
        <?php
        // Display cart items
        $result->data_seek(0); // Reset result pointer
        while ($row = $result->fetch_assoc()) {
            echo "<li>{$row['product_name']} - $ {$row['product_price']}</li>";
        }
        ?>
    </ul>
    <p>Total Amount: $ <?php echo number_format($total_amount, 2); ?></p>
    <h2>Select Payment Method</h2>
    <form action="process_payment.php" method="POST">
        <label for="payment_method">Payment Method:</label>
        <select name="payment_method" id="payment_method">
            <option value="credit_card">Credit Card</option>
            <option value="paypal">PayPal</option>
            <!-- Add more payment methods as needed -->
        </select>
        <button type="submit">Proceed to Payment</button>
    </form>
</body>
</html>
