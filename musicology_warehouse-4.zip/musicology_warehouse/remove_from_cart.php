<?php
session_start();
include 'includes/db.php';

$response = ['success' => false];

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['cart_item_id'])) {
    $cart_item_id = $_POST['cart_item_id'];
    $conn->query("DELETE FROM cart_items WHERE id = $cart_item_id");
    $response['success'] = true;
}

echo json_encode($response);
?>
