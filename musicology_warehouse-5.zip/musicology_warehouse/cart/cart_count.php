<?php
session_start();
include 'includes/db.php';

$response = ['count' => 0];

if (isset($_SESSION['user_id'])) {
    $customer_id = $_SESSION['user_id'];
    $cart_query = "SELECT COUNT(*) as count FROM cart_items 
                   JOIN carts ON cart_items.cart_id = carts.id 
                   WHERE carts.customer_id = ?";
    $cart_statement = $conn->prepare($cart_query);
    $cart_statement->bind_param('i', $customer_id);
    $cart_statement->execute();
    $cart_result = $cart_statement->get_result();
    
    if ($cart_result->num_rows > 0) {
        $cart_count = $cart_result->fetch_assoc();
        $response['count'] = $cart_count['count'];
    }
}

echo json_encode($response);
?>
