<?php
session_start();
include 'includes/db.php';

$response = ['success' => false];

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['cart_item_id']) && isset($_POST['quantity'])) {
    $cart_item_id = $_POST['cart_item_id'];
    $quantity = $_POST['quantity'];

    if ($quantity > 0) {
        // Use prepared statement to prevent SQL injection
        $stmt = $conn->prepare("UPDATE cart_items SET quantity = ? WHERE id = ?");
        $stmt->bind_param('ii', $quantity, $cart_item_id);

        if ($stmt->execute()) {
            $response['success'] = true;
        }
    } else {
        // Use prepared statement to prevent SQL injection
        $stmt = $conn->prepare("DELETE FROM cart_items WHERE id = ?");
        $stmt->bind_param('i', $cart_item_id);

        if ($stmt->execute()) {
            $response['success'] = true;
        }
    }
}

echo json_encode($response);
?>

