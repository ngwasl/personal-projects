$(document).ready(function() {
    // Add to cart
    $('.add-to-cart').on('click', function() {
        var albumId = $(this).data('id');
        addToCart(albumId);
    });

    // Update cart item quantity
    $('.update-quantity').on('change', function() {
        var cartItemId = $(this).data('id');
        var quantity = $(this).val();
        updateCartItemQuantity(cartItemId, quantity);
    });

    // Remove item from cart
    $('.remove-from-cart').on('click', function() {
        var cartItemId = $(this).data('id');
        removeFromCart(cartItemId);
    });

    // Update cart item count in the UI
    function updateCartCount() {
        $.ajax({
            url: 'cart_count.php',
            method: 'GET',
            success: function(response) {
                $('#cart-count').text(response.count);
            },
            error: function(xhr, status, error) {
                console.error('Error updating cart count:', error);
            }
        });
    }

    // Add item to cart
    function addToCart(albumId) {
        $.ajax({
            url: 'add_to_cart.php',
            method: 'POST',
            data: { album_id: albumId },
            success: function(response) {
                if (response.success) {
                    alert('Album added to cart!');
                    updateCartCount();
                } else {
                    alert('Error adding album to cart.');
                }
            },
            error: function(xhr, status, error) {
                console.error('Error adding album to cart:', error);
            }
        });
    }

    // Update cart item quantity
    function updateCartItemQuantity(cartItemId, quantity) {
        $.ajax({
            url: 'update_cart.php',
            method: 'POST',
            data: { cart_item_id: cartItemId, quantity: quantity },
            success: function(response) {
                if (response.success) {
                    alert('Cart updated successfully!');
                    location.reload();
                } else {
                    alert('Error updating cart.');
                }
            },
            error: function(xhr, status, error) {
                console.error('Error updating cart:', error);
            }
        });
    }

    // Remove item from cart
    function removeFromCart(cartItemId) {
        $.ajax({
            url: 'remove_from_cart.php',
            method: 'POST',
            data: { cart_item_id: cartItemId },
            success: function(response) {
                if (response.success) {
                    alert('Item removed from cart!');
                    location.reload();
                } else {
                    alert('Error removing item from cart.');
                }
            },
            error: function(xhr, status, error) {
                console.error('Error removing item from cart:', error);
            }
        });
    }

    // Initial update of cart count
    updateCartCount();
});
