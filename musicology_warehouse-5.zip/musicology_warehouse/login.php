<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
include 'includes/db.php';

$error = ''; // Initialize error variable

// Debugging statement for DB connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} else {
    echo "";
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Debugging statement
    echo "Form submitted. Username: $username, Password: $password <br>";

    // Prepare SQL query
    $stmt = $conn->prepare("SELECT `UserID`, `Username`, `Email`, `Password`, `role` FROM `users` WHERE Username=?");
    $stmt->bind_param('s', $username);
    $stmt->execute();
    $result = $stmt->get_result();

    // Debugging statement
    echo "Query executed. Number of rows: " . $result->num_rows . "<br>";

    // Check if the user exists
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        // Debugging statement
        echo "User found. Password in DB: " . $user['Password'] . "<br>";

        // Verify the password
        if (password_verify($password, $user['Password'])) {
            $_SESSION['user_id'] = $user['UserID'];
            $_SESSION['user_role'] = $user['role']; // Ensure consistency
            $_SESSION['username'] = $user['Username'];

            // Debugging statement
            echo "Password verified. Redirecting to dashboard.php...<br>";

            header("Location: pages/dashboard.php");
            exit();
        } else {
            $error = "Invalid credentials.";
            // Debugging statement
            echo "Password verification failed.<br>";
        }
    } else {
        $error = "Invalid credentials.";
        // Debugging statement
        echo "User not found.<br>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/login.css">
    <script>
        // JavaScript functions 
        function validateForm() {
            var username = document.forms["loginForm"]["username"].value;
            var password = document.forms["loginForm"]["password"].value;
            
            if (username.trim() === "") {
                alert("Username must be filled out");
                return false;
            }
            
            if (password.trim() === "") {
                alert("Password must be filled out");
                return false;
            }
            
            return true;
        }

        function togglePassword() {
            var passwordInput = document.getElementById("password");
            var toggleIcon = document.getElementById("togglePasswordIcon");
            
            if (passwordInput.type === "password") {
                passwordInput.type = "text";
                toggleIcon.textContent = "Hide";
            } else {
                passwordInput.type = "password";
                toggleIcon.textContent = "Show";
            }
        }
    </script>
</head>
<body>
    <div class="login-container">
        <h2>Login</h2>
        <form name="loginForm" method="post" action="login.php" onsubmit="return validateForm()">
            <div>
                <label>Username:</label>
                <input type="text" name="username" required>
            </div>
            <div>
                <label>Password:</label>
                <input type="password" name="password" id="password" required>
                <span class="toggle-password" id="togglePasswordIcon" onclick="togglePassword()">Show</span>
            </div>
            <button type="submit">Login</button>
            <?php if(!empty($error)) { ?>
                <p><?php echo $error; ?></p>
            <?php } ?>
        </form>
        <a href="reset_password.php">Forgot Password?</a>
    </div>
</body>
</html>

