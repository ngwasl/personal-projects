<!-- about.php -->
<h2>About Music Warehouse</h2>
<p>
    Welcome to the Music Warehouse, your ultimate destination for all things music! We are passionate about music and strive to provide music enthusiasts with an unparalleled shopping experience.
</p>
<p>
    At Music Warehouse, we offer a vast selection of albums, singles, and merchandise spanning various genres, ensuring there's something for every music lover. Whether you're into the soulful rhythms of R&B, the energetic beats of hip hop, or the uplifting melodies of gospel, we've got you covered.
</p>
<p>
    Our collection includes timeless classics, chart-topping hits, and hidden gems from iconic artists and emerging talents alike. With our carefully curated selection, you can discover new favorites and rediscover old classics.
</p>
<p>
    In addition to music, we also offer a range of merchandise, including clothing, accessories, and collectibles, allowing you to express your love for music in style.
</p>
<p>
    Music Warehouse is more than just a store – it's a community. We are committed to fostering a vibrant and inclusive music community where fans can connect, share their passion for music, and discover new artists and genres.
</p>
<p>
    Thank you for choosing Music Warehouse as your trusted source for all things music. We look forward to serving you and being a part of your musical journey!
</p>
