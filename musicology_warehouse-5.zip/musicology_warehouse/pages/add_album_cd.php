<?php
// Include the database connection file
include 'includes/db.php';

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve the form data
    $name = $_POST['name'];
    $artist = $_POST['artist'];
    $category = $_POST['category'];
    $stock = $_POST['stock'];

    // Prepare the SQL statement to insert into applicants table
    $sql = "INSERT INTO applicants (Name, Email, Phone, Position) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);

    // Bind parameters and execute the statement
    $stmt->bind_param('ssss', $name, $artist, $category, $stock);
    if ($stmt->execute()) {
        // Record inserted successfully
        echo "New album/CD added successfully.";
    } else {
        // Error occurred while inserting the record
        echo "Error: " . $conn->error;
    }

    // Close the statement and database connection
    $stmt->close();
    $conn->close();
}
?>
