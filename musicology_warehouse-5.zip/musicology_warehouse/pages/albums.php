<?php
session_start();

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

// Include necessary database connection
include '../includes/db.php';

// Fetch albums from the database
$sql = "SELECT * FROM albums";
$result = $conn->query($sql);

// Check if there are any albums
if ($result->num_rows > 0) {
    $albums = $result->fetch_all(MYSQLI_ASSOC);
} else {
    $albums = [];
}

// Handle adding product to cart
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['product_id'])) {
    // Assume add_to_cart.php handles adding the product to the cart
    header("Location: add_to_cart.php?product_id=" . $_POST['product_id']);
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Albums</title>
    <link rel="stylesheet" href="../css/cd_albums.css">
</head>
<body>
    <h1>Albums</h1>
    <div class="product-list">
        <?php foreach ($albums as $album): ?>
            <div class="product">
                <h3><?php echo htmlspecialchars($album['Title']); ?></h3>
                <p>Artist: <?php echo htmlspecialchars($album['Artist']); ?></p>
                <p>Price: $<?php echo number_format($album['Price'], 2); ?></p>
                <p>Stock: <?php echo $album['StockQuantity']; ?></p>
                <!-- Add to Cart form -->
                <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
                    <input type="hidden" name="product_id" value="<?php echo $album['AlbumID']; ?>">
                    <button type="submit">Add to Cart</button>
                </form>
            </div>
        <?php endforeach; ?>
    </div>
</body>
</html>


