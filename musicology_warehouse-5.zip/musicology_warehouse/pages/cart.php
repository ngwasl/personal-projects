<?php
session_start();

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

// Include necessary files
include '../includes/db.php';
include '../includes/functions.php';

// Fetch cart items from the session
$cart_items = isset($_SESSION['cart']) ? $_SESSION['cart'] : [];

// Fetch product details from the database
$products = [];
if (!empty($cart_items)) {
    $ids = implode(',', array_keys($cart_items));
    $sql = "SELECT * FROM products WHERE id IN ($ids)";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $products[] = $row;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Shopping Cart</title>
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <h1>Shopping Cart</h1>
    <div class="cart-items">
        <?php if (empty($products)): ?>
            <p>Your cart is empty.</p>
        <?php else: ?>
            <ul>
                <?php foreach ($products as $product): ?>
                    <li>
                        <h3><?php echo htmlspecialchars($product['title']); ?></h3>
                        <p>Price: $<?php echo number_format($product['price'], 2); ?></p>
                        <p>Quantity: <?php echo $cart_items[$product['id']]; ?></p>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    </div>
    <a href="checkout.php">Checkout</a>
</body>
</html>


