<?php
session_start();

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

// Include necessary database connection
include '../includes/db.php';

// Fetch CDs from the database
$sql = "SELECT * FROM cds";
$result = $conn->query($sql);

// Check if there are any CDs
if ($result->num_rows > 0) {
    $cds = $result->fetch_all(MYSQLI_ASSOC);
} else {
    $cds = [];
}

// Handle adding product to cart
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['product_id'])) {
    // Assume add_to_cart.php handles adding the product to the cart
    header("Location: add_to_cart.php?product_id=" . $_POST['product_id']);
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>CDs</title>
    <link rel="stylesheet" href="../css/cd_albums.css">
</head>
<body>
    <h1>CDs</h1>
    <div class="product-list">
        <?php foreach ($cds as $cd): ?>
            <div class="product">
                <h3><?php echo isset($cd['Title']) ? htmlspecialchars($cd['Title']) : 'N/A'; ?></h3>
                <p>Artist: <?php echo isset($cd['Artist']) ? htmlspecialchars($cd['Artist']) : 'N/A'; ?></p>
                <p>Price: $<?php echo isset($cd['Price']) ? number_format($cd['Price'], 2) : '0.00'; ?></p>
                <p>Stock: <?php echo isset($cd['StockQuantity']) ? $cd['StockQuantity'] : '0'; ?></p>
                <!-- Add to Cart form -->
                <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
                    <input type="hidden" name="product_id" value="<?php echo isset($cd['CDID']) ? $cd['CDID'] : ''; ?>">
                    <button type="submit">Add to Cart</button>
                </form>
            </div>
        <?php endforeach; ?>
    </div>
</body>
</html>

