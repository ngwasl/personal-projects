<?php
session_start();

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

// Include necessary files
include '../includes/db.php';
include '../includes/functions.php';

// Handle payment method selection and order processing here

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Checkout</title>
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <h1>Checkout</h1>
    <form action="process_payment.php" method="post">
        <label for="payment_method">Choose a payment method:</label>
        <select name="payment_method" id="payment_method">
            <option value="credit_card">Credit Card</option>
            <option value="paypal">PayPal</option>
            <!-- Add more payment methods as needed -->
        </select>
        <button type="submit">Proceed to Payment</button>
    </form>
</body>
</html>


