<?php
session_start();

// Redirect users to login page if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

// Include necessary files
include '../includes/db.php';
include '../includes/functions.php';

// Debugging statement for DB connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} else {
    echo "";
}

// Handle increasing stock level
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $productId = $_POST['product_id'];
    $newStock = $_POST['new_stock'];

    // Update stock level in the database
    // Example query, replace with your actual query if needed
    // mysqli_query($conn, "UPDATE your_table SET stock = stock + $newStock WHERE id = $productId");

    // Refresh the page to show updated stock
    header("Location: dashboard.php");
    exit();
}

// Fetch user's details to display their name
$user_id = $_SESSION['user_id'];
$sql = "SELECT Username FROM users WHERE UserID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$username = $user['Username'];

// Placeholder for cart total items, replace with actual value or calculation
$cart_total_items = 10;

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Music Warehouse Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="../css/dashboard.css">
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">The Music Warehouse</div>
            <nav>
                <ul>
                    <li><a href="#">Home</a></li>
                    <li><a href="catalog.php">Catalog</a></li> <!-- Added Catalog link -->
                    <li><a href="#">About</a></li>
                    <li><a href="#">Contact</a></li>
                </ul>
            </nav>
            <div class="cart-container">
                <a href="#" class="cart-icon"><i class="fas fa-shopping-cart"></i></a>
                <span class="cart-value"><?php echo $cart_total_items; ?></span>
            </div>
            <a href="../logout.php" class="logout">Logout</a>
            <div class="search-container">
                <input type="text" class="search-input" placeholder="Search...">
                <i class="fas fa-search search-icon"></i>
            </div>
            <div class="greeting-message">Welcome, <?php echo $username; ?>!</div>
        </div>
    </header>
    <main class="main-content">
        <h1>Admin Dashboard</h1>
        <section>
            <h2>Manage Stock Levels</h2>
            <!-- Removed Albums and CDs sections -->
            <form method="POST" class="increase-stock-form">
                <label for="product_id">Product ID:</label>
                <input type="text" id="product_id" name="product_id" required>
                <label for="new_stock">New Stock Quantity:</label>
                <input type="number" id="new_stock" name="new_stock" required>
                <button type="submit">Increase Stock</button>
            </form>
        </section>
    </main>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js"></script>
    <script>
        function searchProducts() {
            var searchTerm = document.querySelector('.search-input').value;
            console.log('Searching for:', searchTerm);
        }
    </script>
</body>
</html>

