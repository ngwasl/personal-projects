<?php
session_start();
include '../includes/db.php';

// Check if user is logged in and is admin
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] != 'admin') {
    header('Location: ../index.php');
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $product_id = $_POST['product_id'];
    $new_stock = $_POST['new_stock'];

    // Update stock level in the database
    $sql = "UPDATE products SET stock = stock + ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ii', $new_stock, $product_id);
    $stmt->execute();

    // Redirect back to dashboard after updating
    header("Location: dashboard.php");
    exit();
}
?>
