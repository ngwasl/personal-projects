<?php
session_start();

// Ensure the user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Include necessary database connection
include '../includes/db.php';

// Handle stock update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['product_id']) && isset($_POST['new_stock'])) {
    $product_id = $_POST['product_id'];
    $new_stock = $_POST['new_stock'];
    $sql = "UPDATE albums SET stock = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ii', $new_stock, $product_id);
    if (!$stmt->execute()) {
        $sql = "UPDATE cds SET stock = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('ii', $new_stock, $product_id);
        $stmt->execute();
    }
    header("Location: manage_inventory.php");
    exit();
}

// Fetch albums and CDs from the database
$albums = $conn->query("SELECT * FROM albums")->fetch_all(MYSQLI_ASSOC);
$cds = $conn->query("SELECT * FROM cds")->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Inventory</title>
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <h1>Manage Inventory</h1>

    <h2>Albums</h2>
    <div class="product-list">
        <?php foreach ($albums as $album): ?>
            <div class="product">
                <h3><?php echo htmlspecialchars($album['title']); ?></h3>
                <p>Artist: <?php echo htmlspecialchars($album['artist']); ?></p>
                <p>Stock: <?php echo $album['stock']; ?></p>
                <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
                    <input type="hidden" name="product_id" value="<?php echo $album['id']; ?>">
                    <label for="new_stock">New Stock: </label>
                    <input type="number" name="new_stock" required>
                    <button type="submit">Update Stock</button>
                </form>
            </div>
        <?php endforeach; ?>
    </div>

    <h2>CDs</h2>
    <div class="product-list">
        <?php foreach ($cds as $cd): ?>
            <div class="product">
                <h3><?php echo htmlspecialchars($cd['title']); ?></h3>
                <p>Artist: <?php echo htmlspecialchars($cd['artist']); ?></p>
                <p>Stock: <?php echo $cd['stock']; ?></p>
                <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
                    <input type="hidden" name="product_id" value="<?php echo $cd['id']; ?>">
                    <label for="new_stock">New Stock: </label>
                    <input type="number" name="new_stock" required>
                    <button type="submit">Update Stock</button>
                </form>
            </div>
        <?php endforeach; ?>
    </div>
</body>
</html>
