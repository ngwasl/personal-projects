<?php
session_start();

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page if user is not logged in
    header("Location: ../login.php");
    exit();
}

// Check if payment method is selected
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['payment_method'])) {
    // Assuming you have a database connection
    include '../includes/db.php';

    // Get user ID
    $user_id = $_SESSION['user_id'];

    // Fetch user's cart items and total amount
    $sql = "SELECT products.name AS product_name, products.price AS product_price FROM cart INNER JOIN products ON cart.product_id = products.id WHERE cart.user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    // Calculate total amount
    $total_amount = 0;
    while ($row = $result->fetch_assoc()) {
        $total_amount += $row['product_price'];
    }

    // Process payment based on the selected method
    $payment_method = $_POST['payment_method'];
    switch ($payment_method) {
        case 'credit_card':
            // Implement credit card payment processing logic here
            // Redirect user to a payment gateway or show a success message
            // Example: header("Location: credit_card_payment.php");
            break;
        case 'paypal':
            // Implement PayPal payment processing logic here
            // Redirect user to PayPal or show a success message
            // Example: header("Location: paypal_payment.php");
            break;
        // Add more cases for other payment methods if needed
        default:
            // Handle unsupported payment method
            echo "Invalid payment method.";
            break;
    }

    // Clear user's cart after successful payment
    $clear_cart_sql = "DELETE FROM cart WHERE user_id = ?";
    $stmt = $conn->prepare($clear_cart_sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();

    // Redirect user to a success page
    header("Location: payment_success.php");
    exit();
} else {
    // Redirect back to payment methods page if payment method is not selected
    header("Location: payment_methods.php");
    exit();
}
?>
