// add_album.php
<?php
// Database connection
include_once "db_connection.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve album data from form
    $album_name = $_POST["album_name"];
    $album_category = $_POST["album_category"];
    $album_type = $_POST["album_type"];
    $stock_level = $_POST["stock_level"];

    // Insert album data into the database
    $sql = "INSERT INTO albums (album_name, album_category, album_type, stock_level) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssi", $album_name, $album_category, $album_type, $stock_level);
    $stmt->execute();
    $stmt->close();
    $conn->close();
}
?>

