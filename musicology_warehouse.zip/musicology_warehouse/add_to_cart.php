// add_to_cart.php
<?php
// Start session (if not already started)
session_start();

// Check if album ID and quantity are provided
if (isset($_POST["album_id"]) && isset($_POST["quantity"])) {
    $album_id = $_POST["album_id"];
    $quantity = $_POST["quantity"];

    // Add item to cart array in session
    $_SESSION["cart"][$album_id] += $quantity;
}
?>
