<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Album List</title>
</head>
<body>
    <h1>Album List</h1>

    <!-- Fetch albums from the database and display them -->
    <?php
    include_once "db_connect.php";

    // Fetch albums from the database
    $sql = "SELECT * FROM albums";
    $result = $mysqli->query($sql);

    if ($result->num_rows > 0) {
        // Output data of each album
        while ($row = $result->fetch_assoc()) {
            echo "<p>";
            echo "<strong>Album Name:</strong> " . $row["album_name"] . "<br>";
            echo "<strong>Artist:</strong> " . $row["artist"] . "<br>";
            echo "<strong>Album Type:</strong> " . $row["album_type"] . "<br>";
            echo "<strong>Album Category:</strong> " . $row["album_category"] . "<br>";
            echo "<strong>Price:</strong> $" . $row["price"] . "<br>";
            echo "<a href='update_album.php?album_id=" . $row["album_id"] . "'>Edit</a> | ";
            echo "<a href='delete_album.php?album_id=" . $row["album_id"] . "'>Delete</a>";
            echo "</p>";
        }
    } else {
        echo "No albums found.";
    }

    // Close database connection
    $mysqli->close();
    ?>
</body>
</html>
