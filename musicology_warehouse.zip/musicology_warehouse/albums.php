<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Albums</title>
</head>
<body>
    <h1>Albums</h1>

    <!-- Add Album Form -->
    <h2>Add Album</h2>
    <form action="add_album.php" method="post">
        <label for="album_name">Album Name:</label>
        <input type="text" id="album_name" name="album_name" required><br><br>
        <label for="artist">Artist:</label>
        <input type="text" id="artist" name="artist" required><br><br>
        <label for="album_type">Album Type:</label>
        <input type="text" id="album_type" name="album_type" required><br><br>
        <label for="album_category">Album Category:</label>
        <input type="text" id="album_category" name="album_category" required><br><br>
        <label for="price">Price:</label>
        <input type="number" id="price" name="price" step="0.01" required><br><br>
        <button type="submit">Add Album</button>
    </form>

    <!-- List Albums -->
    <h2>Album List
