<?php
session_start();
$token = bin2hex(random_bytes(32));
$_SESSION['csrf_token'] = $token;

// Include this token in your HTML form
echo '<input type="hidden" name="csrf_token" value="' . $token . '">';
?>
