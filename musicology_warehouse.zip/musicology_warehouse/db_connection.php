<?php
// Database connection parameters
$servername = "localhost"; // or your database server name
$username = "root"; // default username for XAMPP MySQL
$password = ""; // empty password for XAMPP MySQL
$database = "musicology_warehouse"; // your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} else {
    echo "Connected successfully"; // Remove this line once you confirm the connection is successful
}
?>

