// delete_album.php
<?php
// Database connection
include_once "db_connection.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve album ID from form
    $album_id = $_POST["album_id"];

    // Delete album from the database
    $sql = "DELETE FROM albums WHERE album_id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $album_id);
    $stmt->execute();
    $stmt->close();
    $conn->close();
}
?>

