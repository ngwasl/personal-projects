// Show an alert message
alert("Welcome to Musicology Warehouse!");
