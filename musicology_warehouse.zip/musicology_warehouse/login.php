<?php

include_once "db_connection.php";
session_start();

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve username and password from form
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Validate username and password (replace with actual validation logic)
    if ($username === "Myuser" && $password === "SA1@123") {
        $_SESSION["username"] = $username;
        $_SESSION["role"] = "admin"; // Assuming only one role for simplicity
        header("Location: dashboard.php"); // Redirect to dashboard after successful login
        exit();
    } else {
        $error = "Invalid username or password";
    }
}
?>

