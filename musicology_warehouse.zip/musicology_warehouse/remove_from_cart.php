// remove_from_cart.php
<?php
// Start session (if not already started)
session_start();

// Check if album ID is provided
if (isset($_POST["album_id"])) {
    $album_id = $_POST["album_id"];

    // Remove item from cart array in session
    unset($_SESSION["cart"][$album_id]);
}
?>
