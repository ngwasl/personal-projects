<?php
// Database connection
include_once "db_connection.php";

// Sanitize user inputs
$username = mysqli_real_escape_string($conn, $_POST['username']);
$password = mysqli_real_escape_string($conn, $_POST['password']);
?>
