// update_album.php
<?php
// Database connection
include_once "db_connection.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve album data from form
    $album_id = $_POST["album_id"];
    $album_name = $_POST["album_name"];
    $album_category = $_POST["album_category"];
    $album_type = $_POST["album_type"];
    $stock_level = $_POST["stock_level"];

    // Update album data in the database
    $sql = "UPDATE albums SET album_name=?, album_category=?, album_type=?, stock_level=? WHERE album_id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssii", $album_name, $album_category, $album_type, $stock_level, $album_id);
    $stmt->execute();
    $stmt->close();
    $conn->close();
}
?>

