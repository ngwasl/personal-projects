// update_cart.php
<?php
// Start session (if not already started)
session_start();

// Check if album ID and new quantity are provided
if (isset($_POST["album_id"]) && isset($_POST["quantity"])) {
    $album_id = $_POST["album_id"];
    $quantity = $_POST["quantity"];

    // Update quantity for item in cart array in session
    $_SESSION["cart"][$album_id] = $quantity;
}
?>


   
