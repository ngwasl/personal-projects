// update_stock.php
<?php
// Database connection
include_once "db_connection.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve album ID and new stock level from form
    $album_id = $_POST["album_id"];
    $new_stock_level = $_POST["new_stock_level"];

    // Update stock level in the database
    $sql = "UPDATE albums SET stock_level=? WHERE album_id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $new_stock_level, $album_id);
    $stmt->execute();
    $stmt->close();
    $conn->close();
}
?>
